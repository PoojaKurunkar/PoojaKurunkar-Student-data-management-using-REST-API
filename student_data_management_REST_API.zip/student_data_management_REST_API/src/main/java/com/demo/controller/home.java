package com.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.student;
import com.demo.service.studentService;

@RestController
@RequestMapping(value = "/student")
public class home {
	
	@Autowired
	private studentService ss;
	
	@PostMapping(value = "/add")
	public student m1(@RequestBody student s)
	{
		return ss.save(s);
	}

	@PutMapping(value = "/add")
	public student m5(@RequestBody student s)
	{
		return ss.save(s);
	}
	
	@DeleteMapping(value = "/deletebysid/{sid}")
	public int m2(@PathVariable("sid")int sid)
	{
		return ss.deleteBySid(sid);
	}
	
	@GetMapping(value = "/findbyscity/{scity}")
	public List<student> m3(@PathVariable("scity")String scity)
	{
		return ss.findByScity(scity);
	}
	
	@GetMapping(value = "/findBysnamestartswith/{sname}")
	public List<student> m4(@PathVariable("sname")String sname)
	{
		return ss.findBySnameStartsWith(sname);
	}
	
	@GetMapping(value = "/findBysnamendswith/{sname}")
	public List<student> m5(@PathVariable("sname")String sname)
	{
		return ss.findBySnameEndsWith(sname);
	}
	@GetMapping(value = "/findBysid/{sid}")
	public student m6(@PathVariable("sid")int sid)
	{
		return ss.findBySid(sid);
	}

}
