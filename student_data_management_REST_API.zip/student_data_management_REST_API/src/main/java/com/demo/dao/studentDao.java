package com.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.model.student;

public interface studentDao extends JpaRepository<student, Integer> {
	List<student> findAll();
	int deleteBySid(int sid);
	List<student> findByScity(String scity);
	List<student> findBySnameStartsWith(String sname);
	List<student> findBySnameEndsWith(String sname);
	student findBySid(int sid);

}
