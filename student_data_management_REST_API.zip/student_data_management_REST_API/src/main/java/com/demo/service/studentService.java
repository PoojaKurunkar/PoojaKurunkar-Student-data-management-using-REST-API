package com.demo.service;

import java.util.List;

import com.demo.model.student;

public interface studentService {
	List<student> findAll();
	student save(student s);
	int deleteBySid(int sid);
	List<student> findByScity(String scity);
	List<student> findBySnameStartsWith(String sname);
	List<student> findBySnameEndsWith(String sname);
	student findBySid(int sid);

}
