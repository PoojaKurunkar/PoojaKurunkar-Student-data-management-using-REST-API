package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.studentDao;
import com.demo.model.student;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class studentServiceimpl implements studentService {

	@Autowired
	private studentDao sd;

	
	public List<student> findAll() {
		return sd.findAll();
	}


	public student save(student s) {
		return sd.save(s);
	}

	public int deleteBySid(int sid) {
		return sd.deleteBySid(sid);
	}


	@Override
	public List<student> findByScity(String scity) {
		return sd.findByScity(scity);
	}

	public List<student> findBySnameStartsWith(String sname) {
		return sd.findBySnameStartsWith(sname);
	}

	public List<student> findBySnameEndsWith(String sname) {
		return sd.findBySnameEndsWith(sname);
	}

	public student findBySid(int sid) {
		return sd.findBySid(sid);
	}

	
}
